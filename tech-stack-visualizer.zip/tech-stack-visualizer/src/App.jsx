import { useState } from 'react';
import html2canvas from 'html2canvas';

const techOptions = {
  Frontend: [
    'React', 'Vue', 'Angular', 'Svelte', 'Next.js', 'Tailwind CSS', 'Bootstrap',
    'HTML', 'CSS', 'JavaScript', 'TypeScript',
  ],
  Backend: [
    'Node.js', 'Express.js', 'NestJS', 'Django', 'Flask', 'Laravel',
    'Spring Boot', 'Ruby on Rails', 'Python', 'Go', 'PHP',
  ],
  Datenbank: [
    'PostgreSQL', 'MySQL', 'MongoDB', 'SQLite', 'Redis',
    'Firebase Realtime DB', 'Supabase', 'Prisma (ORM)',
  ],
  DevOps: [
    'Docker', 'GitHub Actions', 'GitLab CI/CD', 'Kubernetes', 'Vercel',
    'Netlify', 'AWS', 'Azure', 'Terraform', 'Nginx',
  ],
};

function App() {
  const [selectedTech, setSelectedTech] = useState({});
  const [newTool, setNewTool] = useState('');
  const [newCategory, setNewCategory] = useState('Frontend');

  const toggleTech = (category, tech) => {
    setSelectedTech((prev) => {
      const current = prev[category] || [];
      const updated = current.includes(tech)
        ? current.filter((t) => t !== tech)
        : [...current, tech];
      return { ...prev, [category]: updated };
    });
  };

  const addCustomTool = () => {
    const trimmedTool = newTool.trim();
    if (!trimmedTool) return;
    setSelectedTech((prev) => {
      const current = prev[newCategory] || [];
      if (current.includes(trimmedTool)) return prev;
      return {
        ...prev,
        [newCategory]: [...current, trimmedTool],
      };
    });
    setNewTool('');
  };

  const removeTool = (category, tool) => {
    setSelectedTech((prev) => {
      const updated = prev[category].filter((t) => t !== tool);
      if (updated.length === 0) {
        const newStack = { ...prev };
        delete newStack[category];
        return newStack;
      }
      return { ...prev, [category]: updated };
    });
  };

  const exportAsImage = () => {
    const node = document.getElementById('stack-visual');
    html2canvas(node).then((canvas) => {
      const link = document.createElement('a');
      link.download = 'tech-stack.png';
      link.href = canvas.toDataURL();
      link.click();
    });
  };

  return (
    <div style={{ padding: '2rem', fontFamily: 'sans-serif' }}>
      <h1>Project Tech Stack Visualizer</h1>
      <p>Wähle die Technologien für dein Projekt aus:</p>

      {/* ➕ Eigenes Tool hinzufügen */}
      <div style={{ marginBottom: '2rem', padding: '1rem', border: '1px solid #ccc', borderRadius: '8px', background: '#f1f5f9' }}>
        <h2>➕ Eigenes Tool zu "Dein aktueller Stack:" hinzufügen</h2>
        <div style={{ display: 'flex', gap: '1rem', flexWrap: 'wrap', alignItems: 'center' }}>
          <select value={newCategory} onChange={(e) => setNewCategory(e.target.value)}>
            {Object.keys(techOptions).map((cat) => (
              <option key={cat} value={cat}>{cat}</option>
            ))}
          </select>
          <input
            type="text"
            placeholder="z. B. Strapi"
            value={newTool}
            onChange={(e) => setNewTool(e.target.value)}
            style={{ flexGrow: 1, padding: '0.5rem' }}
          />
          <button onClick={addCustomTool} style={{ padding: '0.5rem 1rem' }}>Hinzufügen</button>
        </div>
      </div>

      {/* Vorauswahl aus festen Optionen */}
      {Object.entries(techOptions).map(([category, techs]) => (
        <div key={category}>
          <h2>{category}</h2>
          <div style={{ display: 'flex', gap: '0.5rem', flexWrap: 'wrap' }}>
            {techs.map((tech) => (
              <button
                key={tech}
                onClick={() => toggleTech(category, tech)}
                style={{
                  padding: '0.5rem 1rem',
                  borderRadius: '6px',
                  border: '1px solid #ccc',
                  backgroundColor: selectedTech[category]?.includes(tech)
                    ? '#4ade80'
                    : '#f3f4f6',
                }}
              >
                {tech}
              </button>
            ))}
          </div>
        </div>
      ))}

      <hr style={{ margin: '2rem 0' }} />

      <h2>Dein aktueller Stack:</h2>
      <button onClick={exportAsImage} style={{ marginBottom: '1rem', padding: '0.5rem 1rem' }}>
        📷 Stack als Bild (.png) speichern
      </button>

      <div id="stack-visual" style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '1rem' }}>
        {Object.entries(selectedTech).map(([category, tools]) => (
          <div key={category} style={{ border: '1px solid #ccc', padding: '1rem', borderRadius: '8px', background: '#f9fafb' }}>
            <h3>{category}</h3>
            <ul>
              {tools.map((tool) => (
                <li key={tool} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '2px 0' }}>
                  <span>{tool}</span>
                  <button
                    onClick={() => removeTool(category, tool)}
                    style={{
                      background: 'transparent',
                      border: 'none',
                      color: '#ef4444',
                      cursor: 'pointer',
                      fontSize: '1rem',
                      marginLeft: '0.5rem',
                    }}
                    title="Entfernen"
                  >
                    🗑️
                  </button>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>
    </div>
  );
}

export default App;
